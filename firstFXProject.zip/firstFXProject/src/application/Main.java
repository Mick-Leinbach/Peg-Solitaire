package application;
	
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.shape.Line;
import javafx.scene.text.*;
import javafx.scene.layout.*;


public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {
			// Create text
			Text t = new Text();
			t.setFont(new Font(20));
			t.setWrappingWidth(200);
			t.setTextAlignment(TextAlignment.JUSTIFY);
			t.setText("The quick brown fox jumps over the lazy dog");
			
			// Create lines
			Line line1 = new Line();
			line1.setStartX(20.0f);
			line1.setStartY(110.0f);
			line1.setEndX(540.0f);
			line1.setEndY(110.0f);
		
			Line line2 = new Line();
			line2.setStartX(20.0f);
			line2.setStartY(110.0f);
			line2.setEndX(20.0f);
			line2.setEndY(230.0f);
			
			Line line3 = new Line();
			line3.setStartX(20.0f);
			line3.setStartY(230.0f);
			line3.setEndX(540.0f);
			line3.setEndY(230.0f);
			
			Line line4 = new Line();
			line4.setStartX(540.0f);
			line4.setStartY(110.0f);
			line4.setEndX(540.0f);
			line4.setEndY(230.0f);
			
			// Create check box
			CheckBox cb = new CheckBox("CHECK this out");
			cb.setIndeterminate(false);
			
			// Create radio buttons
		    ToggleGroup group = new ToggleGroup();
		    RadioButton button1 = new RadioButton("do");
		    button1.setToggleGroup(group);
		    button1.setSelected(true);
		    RadioButton button2 = new RadioButton("re");
		    button2.setToggleGroup(group);
		    RadioButton button3 = new RadioButton("mi");
		    button3.setToggleGroup(group);
			
	        // Radio button container
	        VBox vbox = new VBox(10); // 10 is spacing between elements
	        vbox.setPadding(new Insets(15));
	        vbox.getChildren().addAll(button1, button2, button3);
		    
			// Create root
			Pane root = new Pane(t, line1, line2, line3, line4, cb, vbox);
			
			// Choose placement of components
			t.setLayoutX(200); // Text
			t.setLayoutY(150);
			cb.setLayoutX(30); // Check box
			cb.setLayoutY(140);
			vbox.setLayoutX(450); // Radio Buttons
			vbox.setLayoutY(115);

			// Create scene
			Scene scene = new Scene(root,600,400);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			
			// Show stage
			primaryStage.setScene(scene);
			primaryStage.setTitle("Baby's first GUI program");
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
