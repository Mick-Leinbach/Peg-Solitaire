package view;
import javafx.scene.canvas.Canvas;

import javafx.scene.control.Button;

import controller.GameController;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import model.EnglishBoard;
import model.DiamondBoard;
import model.HexagonBoard;
import model.Square;
import model.Board;
import model.CellState;

public class BoardView extends Application {
	// Constants
	final int WINDOW_WIDTH = 1024;
	final int WINDOW_HEIGHT = 768;
	
	// Create canvas
	Canvas canvas = new Canvas(WINDOW_WIDTH, WINDOW_HEIGHT);
	GraphicsContext gc = canvas.getGraphicsContext2D();
	
	// Define board constraints
	double boardRatio = 0.6;
	double boardSize = WINDOW_HEIGHT * boardRatio;
	double cellSize = boardSize / Board.GRID_SIZE;
	double circleShrink = 10;
	double xOffset = (WINDOW_WIDTH - boardSize) / 2;
	double yOffset = (WINDOW_HEIGHT - boardSize) / 2;
	boolean gameOver = false;
	boolean messagePinged = false;
	
	// Create board
	EnglishBoard board = new EnglishBoard(7);
	Square[][] grid = board.getGrid();
	
	// Create controller
	GameController controller = new GameController(board);
	
	// Redraws the board based on the current model (grid)
	public void drawBoard(Square[][] grid, GraphicsContext gc, int rowSelected, int colSelected) {
		// Get beginning x and y
		double x = xOffset;
		double y = yOffset;

		// Loop through the grid, drawing its squares.
		for (int row = 0; row < Board.GRID_SIZE; row++) {
			for (int col = 0; col < Board.GRID_SIZE; col++) {
				// Draw peg
				if (grid[row][col].getState() == CellState.PEG) {
					if (rowSelected != -1 && colSelected != -1 && rowSelected == row && colSelected == col) {
						drawPeg(x, y, gc, cellSize, circleShrink, true);
					}
					else {
						drawPeg(x, y, gc, cellSize, circleShrink, false);
					}
				}
				else if (grid[row][col].getState() == CellState.EMPTY) {
					drawEmpty(x, y, gc, cellSize, circleShrink);
				}
				
				// Move x to next cell
				x += cellSize;
			}
			// Reset x and increase y to next cell
			x = xOffset;
			y += cellSize;
		}
	}
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		// Create window
		primaryStage.setTitle("Peg Solitaire");
		primaryStage.setWidth(WINDOW_WIDTH);
		primaryStage.setHeight(WINDOW_HEIGHT);
		
		// Handle mouse clicks
		canvas.setOnMouseClicked(event -> {
		    double mouseX = event.getX();
		    double mouseY = event.getY();
		    
		    // convert to row/col and call controller
		    int row = (int)((mouseY - yOffset) / cellSize);
		    int col = (int)((mouseX - xOffset) / cellSize);
		    
		    // Run click code
		    gameOver = controller.handleClick(row, col);
		    
		    // Redraw the board
		    drawBoard(board.getGrid(), gc, controller.getSelectedRow(), controller.getSelectedCol());
		    
		    // Alert the player if the game is over
		    if (gameOver && !messagePinged) {
		    	Alert alert = new Alert(Alert.AlertType.INFORMATION);
		    	alert.setTitle("Game Over");
		    	alert.setHeaderText("No more valid moves!");
		    	alert.setContentText("Pegs remaining: " + board.countPegs());
		    	messagePinged = true;
		    	alert.showAndWait();
		    }
		});
		
		// Add reset button
		Button resetButton = new Button("Reset");
		resetButton.setOnAction(event -> {
		    controller.handleResetButton();
		    drawBoard(grid, gc, -1, -1);
		    gameOver = false;
		    messagePinged = false;
		});
		
		// Place canvas inside of layout
		Pane root = new Pane();
		root.getChildren().add(canvas);
		resetButton.setLayoutX(800);
		resetButton.setLayoutY(50);
		root.getChildren().add(resetButton);
		Scene scene = new Scene(root, WINDOW_WIDTH, WINDOW_HEIGHT);
		primaryStage.setScene(scene);
		
		// Draw board
		drawBoard(grid, gc, -1, -1);
		
		// Display
		primaryStage.show();
	}
	
	// Draw a square with a peg in it
	public void drawPeg(double x, double y, GraphicsContext gc, double cellSize, double circleShrink, boolean selected) {
		double circleOffset = circleShrink / 2;
		
		// Change rectangle color if selected
		if (selected) {
			gc.setFill(Color.LIGHTBLUE);
		}
		else {
			gc.setFill(Color.WHITE);
		}
		
		gc.setStroke(Color.BLACK);
		gc.fillRect(x, y, cellSize, cellSize);
		gc.strokeRect(x, y, cellSize, cellSize);
		gc.setFill(Color.WHITE);
		gc.fillOval(x + circleOffset, y + circleOffset, cellSize - circleShrink, cellSize - circleShrink);
		gc.strokeOval(x + circleOffset, y + circleOffset, cellSize - circleShrink, cellSize - circleShrink);
	}
	
	// Draw an empty square
	public void drawEmpty(double x, double y, GraphicsContext gc, double cellSize, double circleShrink) {
		double circleOffset = circleShrink / 2;
		gc.setFill(Color.WHITE);
		gc.setStroke(Color.BLACK);
		gc.fillRect(x, y, cellSize, cellSize);
		gc.strokeRect(x, y, cellSize, cellSize);
		gc.setFill(Color.BLACK);
		gc.fillOval(x + circleOffset, y + circleOffset, cellSize - circleShrink, cellSize - circleShrink);
		gc.strokeOval(x + circleOffset, y + circleOffset, cellSize - circleShrink, cellSize - circleShrink);
	}
	
	// Main function
	public static void main(String[] args) {
	    launch(args);
	}
}
