package view;

import javafx.scene.canvas.Canvas;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import controller.GameSession;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import model.EnglishBoard;
import model.DiamondBoard;
import model.HexagonBoard;
import model.Square;
import model.Board;
import model.CellState;

public class BoardView extends Application {
    // Constants
    final int WINDOW_WIDTH = 1024;
    final int WINDOW_HEIGHT = 768;

    // Canvas
    Canvas canvas = new Canvas(WINDOW_WIDTH, WINDOW_HEIGHT);
    GraphicsContext gc = canvas.getGraphicsContext2D();

    // Board display constraints
    double boardRatio = 0.6;
    double boardSize = WINDOW_HEIGHT * boardRatio;
    double cellSize = boardSize / Board.GRID_SIZE;
    double circleShrink = 10;
    double xOffset = (WINDOW_WIDTH - boardSize) / 2;
    double yOffset = (WINDOW_HEIGHT - boardSize) / 2;

    // Single controller — all game state lives here
    GameSession session = new GameSession(new EnglishBoard(7));

    // Redraws the board based on the current model
    public void drawBoard(Square[][] grid, GraphicsContext gc, int rowSelected, int colSelected) {
        double x = xOffset;
        double y = yOffset;

        for (int row = 0; row < Board.GRID_SIZE; row++) {
            for (int col = 0; col < Board.GRID_SIZE; col++) {
                if (grid[row][col].getState() == CellState.PEG) {
                    boolean selected = (rowSelected != -1 && colSelected != -1
                            && rowSelected == row && colSelected == col);
                    drawPeg(x, y, gc, cellSize, circleShrink, selected);
                } else if (grid[row][col].getState() == CellState.EMPTY) {
                    drawEmpty(x, y, gc, cellSize, circleShrink);
                }
                x += cellSize;
            }
            x = xOffset;
            y += cellSize;
        }
    }

    // Creates a new GameSession with a board of the same type as the current one
    private void switchBoard(int size, String type) {
        Board newBoard;
        switch (type) {
            case "Diamond":  newBoard = new DiamondBoard(size);  break;
            case "Hexagon":  newBoard = new HexagonBoard(size);  break;
            default:         newBoard = new EnglishBoard(size);  break;
        }
        session = new GameSession(newBoard);
        gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
        drawBoard(session.getBoard().getGrid(), gc, -1, -1);
    }

    // Returns the board type string of the current session's board
    private String currentBoardType() {
        Board b = session.getBoard();
        if (b instanceof DiamondBoard) return "Diamond";
        if (b instanceof HexagonBoard) return "Hexagon";
        return "English";
    }

    // Shows the game over alert if needed
    private void checkGameOver() {
        if (session.isGameOver() && !session.isMessagePinged()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Game Over");
            alert.setHeaderText("No more valid moves!");
            alert.setContentText("Pegs remaining: " + session.getBoard().countPegs());
            session.setMessagePinged(true);
            alert.showAndWait();
        }
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("Peg Solitaire");
        primaryStage.setWidth(WINDOW_WIDTH);
        primaryStage.setHeight(WINDOW_HEIGHT);

        // Mouse click handler
        canvas.setOnMouseClicked(event -> {
            int row = (int) ((event.getY() - yOffset) / cellSize);
            int col = (int) ((event.getX() - xOffset) / cellSize);

            session.handleClick(row, col);
            drawBoard(session.getBoard().getGrid(), gc,
                    session.getMC().getSelectedRow(),
                    session.getMC().getSelectedCol());
            checkGameOver();
        });

        // Reset button
        Button resetButton = new Button("Reset");
        resetButton.setOnAction(event -> {
            session.handleResetButton();
            drawBoard(session.getBoard().getGrid(), gc, -1, -1);
        });

        // Auto-play button
        Button autoplayButton = new Button("Auto-play");
        autoplayButton.setOnAction(event -> {
            session.handleAutoPlay();
            drawBoard(session.getBoard().getGrid(), gc, -1, -1);
            checkGameOver();
        });

        // Randomize button
        Button randomButton = new Button("Randomize");
        randomButton.setOnAction(event -> {
            session.handleRandomize();
            drawBoard(session.getBoard().getGrid(), gc, -1, -1);
        });

        // Board size combo box
        ComboBox<Integer> comboBox = new ComboBox<>();
        comboBox.getItems().addAll(5, 7, 9, 11, 13, 15);
        comboBox.setValue(7);
        comboBox.setOnAction(e -> switchBoard(comboBox.getValue(), currentBoardType()));

        Label sizeLabel = new Label("Board Size ");

        // Board type radio buttons
        ToggleGroup group = new ToggleGroup();
        RadioButton op1 = new RadioButton("English");
        RadioButton op2 = new RadioButton("Diamond");
        RadioButton op3 = new RadioButton("Hexagon");
        op1.setToggleGroup(group);
        op2.setToggleGroup(group);
        op3.setToggleGroup(group);
        op1.setSelected(true);
        VBox radRoot = new VBox(10, op1, op2, op3);
        Label typeLabel = new Label("Board Type");

    	// Change the board type based on radio button
        group.selectedToggleProperty().addListener((obs, oldval, newval) -> {
            if (newval != null) {
                String type = ((RadioButton) newval).getText();
                int size = session.getBoard().getBoardSize();
                switchBoard(size, type);
            }
        });

        // Layout
        Pane root = new Pane();
        root.getChildren().add(canvas);

    	// Component layouts
        resetButton.setLayoutX(800);    resetButton.setLayoutY(250);
        autoplayButton.setLayoutX(800); autoplayButton.setLayoutY(280);
        randomButton.setLayoutX(800);   randomButton.setLayoutY(310);
        sizeLabel.setLayoutX(800);      sizeLabel.setLayoutY(53);
        comboBox.setLayoutX(870);       comboBox.setLayoutY(50);
        typeLabel.setLayoutX(800);      typeLabel.setLayoutY(120);
        radRoot.setLayoutX(800);        radRoot.setLayoutY(150);

    	// Add components
        root.getChildren().addAll(resetButton, autoplayButton, randomButton,
                sizeLabel, comboBox, typeLabel, radRoot);

    	// Create scene and display it
        Scene scene = new Scene(root, WINDOW_WIDTH, WINDOW_HEIGHT);
        primaryStage.setScene(scene);
        drawBoard(session.getBoard().getGrid(), gc, -1, -1);
        primaryStage.show();
    }

	// Draw a white circle to represent a peg
    public void drawPeg(double x, double y, GraphicsContext gc, double cellSize, double circleShrink, boolean selected) {
        double circleOffset = circleShrink / 2;
        gc.setFill(selected ? Color.LIGHTBLUE : Color.WHITE);
        gc.setStroke(Color.BLACK);
        gc.fillRect(x, y, cellSize, cellSize);
        gc.strokeRect(x, y, cellSize, cellSize);
        gc.setFill(Color.WHITE);
        gc.fillOval(x + circleOffset, y + circleOffset, cellSize - circleShrink, cellSize - circleShrink);
        gc.strokeOval(x + circleOffset, y + circleOffset, cellSize - circleShrink, cellSize - circleShrink);
    }
    
    // Draw a black circle to represent an empty space
    public void drawEmpty(double x, double y, GraphicsContext gc, double cellSize, double circleShrink) {
        double circleOffset = circleShrink / 2;
        gc.setFill(Color.WHITE);
        gc.setStroke(Color.BLACK);
        gc.fillRect(x, y, cellSize, cellSize);
        gc.strokeRect(x, y, cellSize, cellSize);
        gc.setFill(Color.BLACK);
        gc.fillOval(x + circleOffset, y + circleOffset, cellSize - circleShrink, cellSize - circleShrink);
        gc.strokeOval(x + circleOffset, y + circleOffset, cellSize - circleShrink, cellSize - circleShrink);
    }

    public static void main(String[] args) {
        launch(args);
    }
}