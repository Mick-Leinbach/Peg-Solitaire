package model;

public class Square {
	
	// Declare fields
	private int row;
	private int col;
	private CellState state;
	
	// Constructor
	public Square(int row, int col, CellState state) {
		this.row = row;
		this.col = col;
		this.state = state;
	}

	/**
	 * @return the row #
	 */
	public int getRow() {
		return row;
	}

	/**
	 * @return the column #
	 */
	public int getCol() {
		return col;
	}

	/**
	 * @return the state
	 */
	public CellState getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(CellState state) {
		this.state = state;
	}
}
