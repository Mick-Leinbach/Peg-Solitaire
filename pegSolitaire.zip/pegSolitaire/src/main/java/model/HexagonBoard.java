package model;

public class HexagonBoard extends Board {
	public HexagonBoard(int boardSize) {
		super(boardSize);
		initializeBoard();
	}

	public void initializeBoard() {
		// Initialize variables
		int margin = (GRID_SIZE - boardSize) / 2; 	// How much blank space goes beyond the board
		int center = GRID_SIZE / 2;					// Middle coordinate
		int width;									// Dynamic variable to cut edges off rows to form hexagon shape
		
		int row = 0;
		width = 0;
		
		// Top margin
		while (row < margin) {
			for (int col = 0; col < GRID_SIZE; col++) {
				grid[row][col] = new Square(row, col, CellState.INVALID);
			}
			row++;
			System.out.println();
		}
		
		// Widen out to center
		width++;
		while (row < center - 1) {
			for (int col = 0; col < GRID_SIZE; col++) {
				if (Math.abs(col - center) > width) {
					grid[row][col] = new Square(row, col, CellState.INVALID);
				}
				else {
					grid[row][col] = new Square(row, col, CellState.PEG);
				}
			}
			row++;
			width++;
			System.out.println();
		}
		
		// Center
		while (row < center + 1) {
			for (int col = 0; col < GRID_SIZE; col++) {
				if (Math.abs(col - center) > width) {
					grid[row][col] = new Square(row, col, CellState.INVALID);
				}
				else {
					grid[row][col] = new Square(row, col, CellState.PEG);
				}
			}
			row++;
			System.out.println();
		}
		
		// Thin out to bottom
		while (row < GRID_SIZE - margin) {
			for (int col = 0; col < GRID_SIZE; col++) {
				if (Math.abs(col - center) > width) {
					grid[row][col] = new Square(row, col, CellState.INVALID);
				}
				else {
					grid[row][col] = new Square(row, col, CellState.PEG);
				}
			}
			row++;
			width--;
		}
		
		// Bottom margin
		while (row < GRID_SIZE) {
			for (int col = 0; col < GRID_SIZE; col++) {
				grid[row][col] = new Square(row, col, CellState.INVALID);
				System.out.print(" ");
			}
			row++;
		}
		
		// Center hole
		grid[center][center].setState(CellState.EMPTY);
	}
}