package model;

public class EnglishBoard extends Board {
	public EnglishBoard(int boardSize) {
		super(boardSize);
		initializeBoard();
	}

	public void initializeBoard() {
		// Initialize variables
		int offset = (GRID_SIZE - boardSize) / 2; 	// How much blank space goes beyond the board
		int gapSideLength = (boardSize - 3) / 2; 	// How big the invalid corners are on an English board
		int minBound = offset;					 	// First valid row/column to put pegs in
		int maxBound = GRID_SIZE - offset - 1;		// Last valid row/column to put pegs in	
		int center = GRID_SIZE / 2;					// Middle coordinate
		
		// Iterate through grid and initialize squares correctly
		for (int row = 0; row < GRID_SIZE; row++) {
			for (int col = 0; col < GRID_SIZE; col++) {
				// If cell is outside of board boundaries, automatically set it to invalid
				if ((row < minBound) || (row > maxBound) || (col < minBound) || (col > maxBound)) {
					grid[row][col] = new Square(row, col, CellState.INVALID);
				}
				// If cell is in corner of board, set to invalid
				else if (((row < minBound + gapSideLength) || (row > maxBound - gapSideLength)) && ((col < minBound + gapSideLength) || (col > maxBound - gapSideLength))) {
					grid[row][col] = new Square(row, col, CellState.INVALID);
				}
				// If we're in the middle cell, set the square to empty
				else if ((row == center) && (col == center)) {
					grid[row][col] = new Square(row, col, CellState.EMPTY);
				}
				// Otherwise, place peg
				else
				{
					grid[row][col] = new Square(row, col, CellState.PEG);
				}
			}
			System.out.println();
		}
	}
}
