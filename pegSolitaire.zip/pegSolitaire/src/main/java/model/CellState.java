package model;

public enum CellState {
	PEG, EMPTY, INVALID;
}
