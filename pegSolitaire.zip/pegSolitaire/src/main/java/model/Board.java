package model;

public abstract class Board {
	// Fields
	public static final int GRID_SIZE = 15;
	protected Square[][] grid;
	int boardSize;
	
	// Constructor
	public Board(int boardSize) {
		grid = new Square[GRID_SIZE][GRID_SIZE];
		this.boardSize = boardSize;
	}
	
	// Extensions of this class must initialize a board
	public abstract void initializeBoard();
	
	// Function to count number of pegs remaining
	public int countPegs() {
		int peg = 0;
		for (int row = 0; row < GRID_SIZE; row++){
			for (int col = 0; col < GRID_SIZE; col++) {
				if (grid[row][col].getState() == CellState.PEG) {
					peg++;
				}	
			}
		}
		return peg;
	}
	
	// Checks all 8 moves for each remaining peg, returning true as soon as one is found to exist and false if none do
	public boolean validMovesExist() {
		for (int row = 0; row < GRID_SIZE; row++){
			for (int col = 0; col < GRID_SIZE; col++) {
				if (grid[row][col].getState() == CellState.PEG) {
					if (
						(isValid(row,col,row-2,col)) ||
						(isValid(row,col,row-2,col+2)) ||
						(isValid(row,col,row, col+2)) ||
						(isValid(row,col,row+2, col+2)) ||
						(isValid(row,col,row+2, col)) || 
						(isValid(row,col,row+2, col-2)) ||
						(isValid(row,col,row, col-2)) ||
						(isValid(row,col,row-2, col-2))) {
						return true;
					}
				}	
			}
		}
		return false;
	}
	
	// Set all empty spaces back to being filled in, but empty the very center square.
	public void resetBoard() {
		// Fill in all valid squares with pegs
		for (int row = 0; row < GRID_SIZE; row++) {
			for (int col = 0; col < GRID_SIZE; col++) {
				if (grid[row][col].getState() == CellState.EMPTY) {
					grid[row][col].setState(CellState.PEG);
				}
			}
		}
		
		// Reset middle square
		grid[7][7].setState(CellState.EMPTY);
	}
	
	
	// Function to check whether or not a possible move is valid
	public boolean isValid(int rstart, int cstart, int rend, int cend) {
		boolean validOrtho = false;
		boolean validDiag = false;
		
		// Ignoring square types, determine if displacement fits the pattern of a valid orthogonal or diagonal move
		// Orthogonal
		if (((rstart == rend) && (Math.abs(cstart - cend) == 2)) || ((cstart == cend) && (Math.abs(rstart - rend) == 2))) {
			validOrtho = true;
		}
		// Diagonal
		else if ((Math.abs(cstart - cend) == 2) && (Math.abs(rend - rstart) == 2)) {
			validDiag = true;
		}
		
		// If displacement isn't valid, return false
		if (!validOrtho && !validDiag) {
			return false;
		}
		
		
		try {
			// Starting and ending peg
			Square start = grid[rstart][cstart];
			Square end = grid[rend][cend];
			
			
			// If starting position invalid or empty, return false
			if (start.getState() != CellState.PEG) {
				return false;
			}
			
			// If ending position is filled or invalid, return false
			if (end.getState() != CellState.EMPTY) {
				return false;
			}
			
			// If we've jumped over an empty peg orthogonally, return false
			if (validOrtho) {
				// Moving right
				if (cstart < cend) {
					if (grid[rstart][cstart + 1].getState() != CellState.PEG) {
						return false;
					}
				}
				// Moving left
				else if (cstart > cend) {
					if (grid[rstart][cstart - 1].getState() != CellState.PEG) {
						return false;
					}			
				}
				// Moving up
				else if (rstart > rend) {
					if (grid[rstart - 1][cstart].getState() != CellState.PEG) {
						return false;
					}			
				}
				// Moving down
				else if (rstart < rend) {
					if (grid[rstart + 1][cstart].getState() != CellState.PEG) {
						return false;
					}			
				}
			}
			// If we've jumped over an empty peg diagonally, return false
			else if (validDiag) {
				// Up-right
				if ((rstart > rend) && (cstart < cend)) {
					if (grid[rstart - 1][cstart + 1].getState() != CellState.PEG) {
						return false;
					}		
				}
				// down-right
				else if ((rstart < rend) && (cstart < cend)) {
					if (grid[rstart + 1][cstart + 1].getState() != CellState.PEG) {
						return false;
					}		
				}
				// down-left
				else if ((rstart < rend) && (cstart > cend)) {
					if (grid[rstart + 1][cstart - 1].getState() != CellState.PEG) {
						return false;
					}		
				}
				// up-left
				else if ((rstart > rend) && (cstart > cend)) {
					if (grid[rstart - 1][cstart - 1].getState() != CellState.PEG) {
						return false;
					}		
				}
			}
			
			return true;
		}
		catch (ArrayIndexOutOfBoundsException e) {
			return false;
		}
	}

	
	public boolean makeMove(int rstart, int cstart, int rend, int cend) {
		if (isValid(rstart, cstart, rend, cend)) {
			// Determine position of middle (removed) peg
			int middle_row = (rstart + rend) / 2;
			int middle_column = (cstart + cend) / 2;
			
			// Make the move
			grid[rstart][cstart].setState(CellState.EMPTY);
			grid[middle_row][middle_column].setState(CellState.EMPTY);
			grid[rend][cend].setState(CellState.PEG);
			
			return true;
		}
		// Do nothing and return false if move is not valid
		else {
			return false;
		}
	}
	
	/**
	 * @return the boardSize
	 */
	public int getBoardSize() {
		return boardSize;
	}

	/**
	 * @return the grid
	 */
	public Square[][] getGrid() {
		return grid;
	}

	/**
	 * @param grid the grid to set
	 */
	public void setGrid(Square[][] grid) {
		this.grid = grid;
	}
}