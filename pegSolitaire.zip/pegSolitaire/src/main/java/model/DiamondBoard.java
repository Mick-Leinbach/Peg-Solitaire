package model;

public class DiamondBoard extends Board {
	public DiamondBoard(int boardSize) {
		super(boardSize);
		initializeBoard();
	}

	public void initializeBoard() {
		// Initialize variables
		int margin = (GRID_SIZE - boardSize) / 2; 	// How much blank space goes beyond the board
		int center = GRID_SIZE / 2;					// Middle coordinate
		int offset;									// Dynamic variable to cut edges off rows to form diamond shape
		
		// Iterate through grid and initialize squares correctly
		for (int row = 0; row < GRID_SIZE; row++) {
			offset = margin + Math.abs(row - center);
			for (int col = 0; col < GRID_SIZE; col++) {
				if ((col < offset) || (col > GRID_SIZE - 1 - offset)) {
					grid[row][col] = new Square(row, col, CellState.INVALID);
					System.out.print(" ");
				}
				else {
					grid[row][col] = new Square(row, col, CellState.PEG);
				}
			}
			System.out.println();
		}
		
		// Empty middle square
		grid[center][center].setState(CellState.EMPTY);
	}
}
