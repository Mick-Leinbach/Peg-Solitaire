package controller;

import java.util.List;
import java.util.Random;

import model.Board;
import model.Move;

public class AutomatedGame {
    private final Random randomGenerator = new Random();
    private Board board;

    public AutomatedGame(Board board) {
        this.board = board;
    }

    // Returns true if the move ended the game, false otherwise
    public boolean makeRandomMove() {
        List<Move> moveList = board.getValidMoves();
        try {
            int index = randomGenerator.nextInt(moveList.size());
            Move randomMove = moveList.get(index);
            board.makeMove(randomMove.getStartR(), randomMove.getStartC(),
                           randomMove.getEndR(), randomMove.getEndC());
            return !board.validMovesExist();
        } catch (IllegalArgumentException e) {
            return true;
        }
    }
}