package controller;

import model.Board;
import model.CellState;

public class ManualGame {
    private int selectedRow;
    private int selectedCol;
    private Board board;

    public ManualGame(Board board) {
        this.board = board;
        selectedRow = -1;
        selectedCol = -1;
    }

    // Returns true if the move ended the game, false otherwise
    public boolean handleClick(int clickedRow, int clickedCol) {
        if ((clickedRow < 0) || (clickedRow > board.GRID_SIZE - 1) ||
            (clickedCol < 0) || (clickedCol > board.GRID_SIZE - 1)) {
            return false;
        }

        if ((clickedRow == selectedRow) && (clickedCol == selectedCol)) {
            selectedRow = -1;
            selectedCol = -1;
        }
        else if (board.getGrid()[clickedRow][clickedCol].getState() == CellState.INVALID) {
            selectedRow = -1;
            selectedCol = -1;
        }
        else if (board.getGrid()[clickedRow][clickedCol].getState() == CellState.EMPTY) {
            if (selectedRow == -1 || !board.isValid(selectedRow, selectedCol, clickedRow, clickedCol)) {
                selectedRow = -1;
                selectedCol = -1;
            } else {
                board.makeMove(selectedRow, selectedCol, clickedRow, clickedCol);
                selectedRow = -1;
                selectedCol = -1;
                return !board.validMovesExist();
            }
        }
        else if (board.getGrid()[clickedRow][clickedCol].getState() == CellState.PEG) {
            selectedRow = clickedRow;
            selectedCol = clickedCol;
        }

        return false;
    }

    public int getSelectedRow() {
        return selectedRow;
    }

    public int getSelectedCol() {
        return selectedCol;
    }
}