package controller;

import model.Board;
import model.EnglishBoard;

public class GameSession {
    private Board board;
    private boolean gameOver;
    private boolean messagePinged;
    private ManualGame manualController;
    private AutomatedGame automatedController;

    // Constructor
    public GameSession(Board board) {
        this.board = board;
        this.gameOver = false;
        this.messagePinged = false;
        this.manualController = new ManualGame(board);
        this.automatedController = new AutomatedGame(board);
    }

    // Handle a manual click — delegates to ManualGame, then checks game state
    public void handleClick(int row, int col) {
        if (gameOver) return;
        boolean ended = manualController.handleClick(row, col);
        if (ended) {
            gameOver = true;
        }
    }

    // Handle an auto-play step — delegates to AutomatedGame, then checks game state
    public void handleAutoPlay() {
        if (gameOver) return;
        boolean ended = automatedController.makeRandomMove();
        if (ended) {
            gameOver = true;
        }
    }

    // Reset the board and all session state
    public void handleResetButton() {
        board.resetBoard();
        gameOver = false;
        messagePinged = false;
        manualController = new ManualGame(board);
        automatedController = new AutomatedGame(board);
    }

    // Randomize the board and reset session state
    public void handleRandomize() {
        board.randomize();
        while (!board.validMovesExist()) {
            board.randomize();
        }
        gameOver = false;
        messagePinged = false;
        manualController = new ManualGame(board);
        automatedController = new AutomatedGame(board);
    }

    // Getters and setters

    public Board getBoard() {
        return board;
    }

    public boolean isGameOver() {
        return gameOver;
    }

    public boolean isMessagePinged() {
        return messagePinged;
    }

    public void setMessagePinged(boolean messagePinged) {
        this.messagePinged = messagePinged;
    }

    public ManualGame getMC() {
        return manualController;
    }

    public AutomatedGame getAC() {
        return automatedController;
    }
}