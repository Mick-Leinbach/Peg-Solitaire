package controller;
import model.Board;
import model.CellState;

public class GameController {
	private Board board;
	private int selectedRow;
	private int selectedCol;
	private boolean hasPegSelected;	// True if selectedRow & selectedCol have meaningful values, false otherwise.
	private boolean gameOver = false;
	
	public GameController(Board board) {
		this.board = board;
	}
	
	// The code to run on the model end of things whenever a click is made
	// Returns true if the click ends the game and false otherwise
	public boolean handleClick(int clickedRow, int clickedCol) {
		// Abort if the game is over
		if (gameOver) {
			clickedRow = -1;
			clickedCol = -1;
			return true;
		}
		
		// Abort if we haven't clicked a valid cell
		if ((clickedRow < 0) || (clickedRow > board.GRID_SIZE - 1) || (clickedCol < 0) || (clickedCol > board.GRID_SIZE - 1)) {
			return false;
		}
		
		// Case 1: We've clicked a cell that's already selected
		if ((clickedRow == selectedRow) && (clickedCol == selectedCol)) {
			selectedRow = -1;
			selectedCol = -1;
		}
		// Case 2: We've clicked an invalid cell
		else if (board.getGrid()[clickedRow][clickedCol].getState() == CellState.INVALID) {
			selectedRow = -1;
			selectedCol = -1;
		}
		// Case 3: We've clicked an empty cell but it's not a valid move
		else if (board.getGrid()[clickedRow][clickedCol].getState() == CellState.EMPTY) {
		    if (selectedRow == -1 || !board.isValid(selectedRow, selectedCol, clickedRow, clickedCol)) {
		        selectedRow = -1;
		        selectedCol = -1;
		    } else {
		    	// Make the move
		        board.makeMove(selectedRow, selectedCol, clickedRow, clickedCol);
		        
		        // De-select
		        selectedRow = -1;
		        selectedCol = -1;
		        
		        // Alert player if the game is over
		        if (!board.validMovesExist()) {
		        	gameOver = true;
		        	return true;
		        }
		    }
		}
		// Case 4: We've clicked on another peg
		else if (board.getGrid()[clickedRow][clickedCol].getState() == CellState.PEG) {
			selectedRow = clickedRow;
			selectedCol = clickedCol;
		}
		
		return false;
	}
	
	// Reset!
	public void handleResetButton() {
		board.resetBoard();
		gameOver = false;
	}
	
	/**
	* @return the selectedRow
		 */
		public int getSelectedRow() {
		return selectedRow;
	}
		
	/**
	* @return the selectedCol
		 */
		public int getSelectedCol() {
		return selectedCol;
	}
}
