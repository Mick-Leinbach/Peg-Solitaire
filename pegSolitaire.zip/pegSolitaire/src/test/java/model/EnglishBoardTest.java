package model;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class EnglishBoardTest {
	
	@Test
	public void testBoardSize() {
		EnglishBoard englishBoard = new EnglishBoard(7);
		assertEquals(7, englishBoard.getBoardSize());
	}
	
	@Test
	public void testSizeSevenBoard() {
		EnglishBoard englishBoard = new EnglishBoard(7);
		assertEquals(CellState.INVALID, englishBoard.getGrid()[5][5].getState());
		assertEquals(CellState.INVALID, englishBoard.getGrid()[9][5].getState());
		assertEquals(CellState.INVALID, englishBoard.getGrid()[5][9].getState());
		assertEquals(CellState.INVALID, englishBoard.getGrid()[9][9].getState());
		assertEquals(CellState.EMPTY, englishBoard.getGrid()[7][7].getState());
		assertEquals(CellState.PEG, englishBoard.getGrid()[5][6].getState());
		assertEquals(CellState.PEG, englishBoard.getGrid()[8][8].getState());
	}
	
	@Test 
	public void testSizeFifteenBoard() {
		EnglishBoard englishBoard = new EnglishBoard(15);
		assertEquals(CellState.INVALID, englishBoard.getGrid()[5][5].getState());
		assertEquals(CellState.INVALID, englishBoard.getGrid()[9][5].getState());
		assertEquals(CellState.INVALID, englishBoard.getGrid()[5][9].getState());
		assertEquals(CellState.INVALID, englishBoard.getGrid()[9][9].getState());
		assertEquals(CellState.EMPTY, englishBoard.getGrid()[7][7].getState());
		assertEquals(CellState.PEG, englishBoard.getGrid()[5][6].getState());
		assertEquals(CellState.PEG, englishBoard.getGrid()[8][8].getState());
		assertEquals(CellState.PEG, englishBoard.getGrid()[0][6].getState());
	}
	
	@Test
	public void testJumpRemovesPeg() {
		EnglishBoard board = new EnglishBoard(7);
		Square[][] grid = board.getGrid();
		grid[7][9].setState(CellState.PEG);
		grid[7][8].setState(CellState.PEG);
		grid[7][7].setState(CellState.EMPTY);
		
		assertTrue(
				board.makeMove(7,9,7,7) &&
				grid[7][9].getState() == CellState.EMPTY &&
				grid[7][8].getState() == CellState.EMPTY &&
				grid[7][7].getState() == CellState.PEG);
	}
	
	@Test
	public void testDiagJumpRemovesPeg() {
		EnglishBoard board = new EnglishBoard(7);
		Square[][] grid = board.getGrid();
		grid[4][8].setState(CellState.PEG);
		grid[5][7].setState(CellState.PEG);
		grid[6][6].setState(CellState.EMPTY);
		
		assertTrue(
				board.makeMove(4,8,6,6) &&
				grid[4][8].getState() == CellState.EMPTY &&
				grid[5][7].getState() == CellState.EMPTY &&
				grid[6][6].getState() == CellState.PEG);
	}
	
	@Test 
	public void testIfNoValidMoves() {
		EnglishBoard board = new EnglishBoard(7);
		Square[][] grid = board.getGrid();
		
		// Empty board
		for (int row = 0; row < board.GRID_SIZE; row++){
			for (int col = 0; col < board.GRID_SIZE; col++) {
				if (grid[row][col].getState() == CellState.PEG) {
					grid[row][col].setState(CellState.EMPTY);
				}	
			}
		}
		
		// Fill in some pegs in a way where there are no valid moves
		grid[7][5].setState(CellState.PEG);
		grid[7][7].setState(CellState.PEG);
		grid[7][9].setState(CellState.PEG);
		grid[5][7].setState(CellState.PEG);
		grid[9][7].setState(CellState.PEG);
		
		// Oracle
		assertFalse(board.validMovesExist());
	}
	
	@Test public void testResetBoard() {
		EnglishBoard board = new EnglishBoard(7);
		Square[][] grid = board.getGrid();
		
		// Empty board
		for (int row = 0; row < board.GRID_SIZE; row++){
			for (int col = 0; col < board.GRID_SIZE; col++) {
				if (grid[row][col].getState() == CellState.PEG) {
					grid[row][col].setState(CellState.EMPTY);
				}	
			}
		}
		
		// Put peg in middle just to be a really emphasize how inverted this is
		grid[7][7].setState(CellState.PEG);
		
		// Reset board
		board.resetBoard();
		
		// Make sure board arrangement is as it should be
		assertEquals(CellState.INVALID, grid[5][5].getState());
		assertEquals(CellState.INVALID, grid[9][5].getState());
		assertEquals(CellState.INVALID, grid[5][9].getState());
		assertEquals(CellState.INVALID, grid[9][9].getState());
		assertEquals(CellState.EMPTY, grid[7][7].getState());
		assertEquals(CellState.PEG, grid[5][6].getState());
		assertEquals(CellState.PEG, grid[8][8].getState());
	}
	
	@Test 
	public void testDetectValidMoves() {
		EnglishBoard board = new EnglishBoard(7);
		Square[][] grid = board.getGrid();

		// Oracle
		assertTrue(board.validMovesExist());
	}
	
	@Test
	public void testValidOrthogonal() {
		EnglishBoard board = new EnglishBoard(7);
		Square[][] grid = board.getGrid();
		grid[9][7].setState(CellState.EMPTY);
		grid[6][6].setState(CellState.EMPTY);
		grid[6][4].setState(CellState.EMPTY);
		grid[7][4].setState(CellState.EMPTY);
		
		assertTrue(board.isValid(6,8,6,6));		// Valid orthogonal move
	}
	
	@Test
	public void testValidDiagonal() {
		EnglishBoard board = new EnglishBoard(7);
		Square[][] grid = board.getGrid();
		grid[9][7].setState(CellState.EMPTY);
		grid[6][6].setState(CellState.EMPTY);
		grid[6][4].setState(CellState.EMPTY);
		grid[7][4].setState(CellState.EMPTY);
		
		assertTrue(board.isValid(8,4,6,6));		// Valid diagonal move
	}
	
	@Test
	public void testValidDiagonal2() {
		EnglishBoard board = new EnglishBoard(7);
		Square[][] grid = board.getGrid();
		grid[9][7].setState(CellState.EMPTY);
		grid[6][6].setState(CellState.EMPTY);
		grid[6][4].setState(CellState.EMPTY);
		grid[7][4].setState(CellState.EMPTY);
		
		assertTrue(board.isValid(4,8,6,6));		// Valid diagonal move #2
	}
	
	@Test
	public void testInvalidStart() {
		EnglishBoard board = new EnglishBoard(7);
		Square[][] grid = board.getGrid();
		grid[9][7].setState(CellState.EMPTY);
		grid[6][6].setState(CellState.EMPTY);
		grid[6][4].setState(CellState.EMPTY);
		grid[7][4].setState(CellState.EMPTY);
		
		assertFalse(board.isValid(9,5,9,7)); 	// Invalid start
	}
	
	@Test
	public void testEmptyStart() {
		EnglishBoard board = new EnglishBoard(7);
		Square[][] grid = board.getGrid();
		grid[9][7].setState(CellState.EMPTY);
		grid[6][6].setState(CellState.EMPTY);
		grid[6][4].setState(CellState.EMPTY);
		grid[7][4].setState(CellState.EMPTY);
		
		assertFalse(board.isValid(7,7,9,7)); 	// Empty start
	}
	
	@Test
	public void testNeighborMove() {
		EnglishBoard board = new EnglishBoard(7);
		Square[][] grid = board.getGrid();
		grid[9][7].setState(CellState.EMPTY);
		grid[6][6].setState(CellState.EMPTY);
		grid[6][4].setState(CellState.EMPTY);
		grid[7][4].setState(CellState.EMPTY);
		
		assertFalse(board.isValid(10,7,9,7));	// Neighbor move
	}
	
	@Test
	public void testDoubleHop() {
		EnglishBoard board = new EnglishBoard(7);
		Square[][] grid = board.getGrid();
		grid[9][7].setState(CellState.EMPTY);
		grid[6][6].setState(CellState.EMPTY);
		grid[6][4].setState(CellState.EMPTY);
		grid[7][4].setState(CellState.EMPTY);
		
		assertFalse(board.isValid(4,7,7,7));	// Double-hop move
	}
	
	@Test
	public void testLongMove() {
		EnglishBoard board = new EnglishBoard(7);
		Square[][] grid = board.getGrid();
		grid[9][7].setState(CellState.EMPTY);
		grid[6][6].setState(CellState.EMPTY);
		grid[6][4].setState(CellState.EMPTY);
		grid[7][4].setState(CellState.EMPTY);
		
		assertFalse(board.isValid(10,6,6,6));  	// Long move
	}
	
	@Test
	public void testEmptyJump() {
		EnglishBoard board = new EnglishBoard(7);
		Square[][] grid = board.getGrid();
		grid[9][7].setState(CellState.EMPTY);
		grid[6][6].setState(CellState.EMPTY);
		grid[6][4].setState(CellState.EMPTY);
		grid[7][4].setState(CellState.EMPTY);
		
		assertFalse(board.isValid(8,4,6,4));	// Jump over empty peg
	}
	
	@Test
	public void testEmptyDiagJump() {
		EnglishBoard board = new EnglishBoard(7);
		Square[][] grid = board.getGrid();
		grid[9][7].setState(CellState.EMPTY);
		grid[6][6].setState(CellState.EMPTY);
		grid[6][4].setState(CellState.EMPTY);
		grid[7][4].setState(CellState.EMPTY);
		
		assertFalse(board.isValid(8,6,8,6));	// Jump over empty peg diagonally
		assertFalse(board.isValid(6, 4, 4, 6)); // Jump over invalid peg diagonally
	}
	
	@Test
	public void testInvalidLanding() {
		EnglishBoard board = new EnglishBoard(7);
		Square[][] grid = board.getGrid();
		grid[9][7].setState(CellState.EMPTY);
		grid[6][6].setState(CellState.EMPTY);
		grid[6][4].setState(CellState.EMPTY);
		grid[7][4].setState(CellState.EMPTY);
		
		assertFalse(board.isValid(8,5,8,3));	// Landing position is invalid
	}
	
	@Test
	public void testOccupiedLanding() {
		EnglishBoard board = new EnglishBoard(7);
		Square[][] grid = board.getGrid();
		grid[9][7].setState(CellState.EMPTY);
		grid[6][6].setState(CellState.EMPTY);
		grid[6][4].setState(CellState.EMPTY);
		grid[7][4].setState(CellState.EMPTY);
		
		assertFalse(board.isValid(8,9,6,9));	// Landing position is occupied
	}
	
	@Test
	public void testOutOfBounds() {
		EnglishBoard board = new EnglishBoard(7);
		Square[][] grid = board.getGrid();
		grid[9][7].setState(CellState.EMPTY);
		grid[6][6].setState(CellState.EMPTY);
		grid[6][4].setState(CellState.EMPTY);
		grid[7][4].setState(CellState.EMPTY);
		
		assertFalse(board.isValid(0,0,-2,0));	// Landing position is occupied
	}
	
	@Test
	public void testDontRandomizeInvalid() {
		EnglishBoard board = new EnglishBoard(7);
		board.randomize();
		Square[][] grid = board.getGrid();
		assertEquals(grid[5][5].getState(), CellState.INVALID);
		assertEquals(grid[5][9].getState(), CellState.INVALID);
		assertEquals(grid[9][5].getState(), CellState.INVALID);
		assertEquals(grid[9][9].getState(), CellState.INVALID);
	}
}