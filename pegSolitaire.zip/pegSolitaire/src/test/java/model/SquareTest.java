package model;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class SquareTest {
	@Test
	public void testInitializePeg() {
		Square square = new Square(0, 0, CellState.PEG);
		assertEquals(CellState.PEG, square.getState());
	}
	
	@Test
	public void testInitializeEmpty() {
		Square square = new Square(0, 0, CellState.EMPTY);
		assertEquals(CellState.EMPTY, square.getState());
	}
	
	@Test
	public void testInitializeInvalid() {
		Square square = new Square(0, 0, CellState.INVALID);
		assertEquals(CellState.INVALID, square.getState());
	}
	
	@Test
	public void testSetState() {
		Square square = new Square(0,0, CellState.EMPTY);
		square.setState(CellState.PEG);
		assertEquals(CellState.PEG, square.getState());
	}
	
	@Test
	public void testRow() {
		Square square = new Square(4, 0, CellState.PEG);
		assertEquals(4, square.getRow());
	}
	
	@Test
	public void testColumn() {
		Square square = new Square(0,4,CellState.PEG);
		assertEquals(4, square.getCol());
	}
}