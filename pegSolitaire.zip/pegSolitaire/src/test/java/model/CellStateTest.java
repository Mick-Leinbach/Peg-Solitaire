package model;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CellStateTest {
	@Test
	public void testEqualsThreeStates() {
		assertEquals(3, CellState.values().length);
	}	
}