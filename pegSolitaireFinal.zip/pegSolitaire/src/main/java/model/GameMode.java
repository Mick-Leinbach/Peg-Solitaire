package model;

public class GameMode {
	boolean replayMode;
	
	public GameMode() {
		this.replayMode = false;
	}
	
	public void setReplay(boolean b) {
		this.replayMode = b;
	}
	
	public boolean isReplay() {
		return replayMode;
	}
}
