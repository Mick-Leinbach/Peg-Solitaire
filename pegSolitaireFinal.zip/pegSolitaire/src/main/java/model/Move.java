package model;

public class Move {
	private int startR;
	private int startC;
	private int endR;
	private int endC;
	
	// Constructor
	public Move(int startR, int startC, int endR, int endC) {
		this.startR = startR;
		this.startC = startC;
		this.endR = endR;
		this.endC = endC;
	}

	/**
	 * @return the startR
	 */
	public int getStartR() {
		return startR;
	}

	/**
	 * @return the startC
	 */
	public int getStartC() {
		return startC;
	}

	/**
	 * @return the endR
	 */
	public int getEndR() {
		return endR;
	}

	/**
	 * @return the endC
	 */
	public int getEndC() {
		return endC;
	}
}
