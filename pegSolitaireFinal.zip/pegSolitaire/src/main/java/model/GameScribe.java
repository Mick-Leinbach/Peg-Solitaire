package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class GameScribe {
	private File gameRecord;
	private BufferedWriter writer;
	private GameMode mode;
	
	public GameScribe(GameMode mode) {
		try {
		    gameRecord = new File("gameRecord.txt");
		    
		    // Wipe new scribe's file just in case
		    wipeFile();
		    
		    writer = new BufferedWriter(new FileWriter(gameRecord));
		    this.mode = mode;
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	// Clear the record
	public void wipeFile() {
		try {
		    BufferedWriter writer = new BufferedWriter(new FileWriter(gameRecord, false));
		    writer.write("");
		    writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	// Add move to the record
	public void writeMove(int rstart, int cstart, int rend, int cend) {
		try {
			// Only add move if isReplay is false
			if (!mode.isReplay()) {
				BufferedWriter writer = new BufferedWriter(new FileWriter(gameRecord, true));
				writer.write(rstart + " " + cstart + " " + rend + " " + cend + "\n");
				writer.close();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	// Write given string to the file
	// Automatically creates new line
	public void writeStringToFile(String s) {
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(gameRecord, true));
			writer.write(s + "\n");
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	// Read file
	public String readFile() {
			try {
		    BufferedReader reader = new BufferedReader(new FileReader(gameRecord));
		    StringBuilder sb = new StringBuilder();
		    String line;
		    while ((line = reader.readLine()) != null) {
		        sb.append(line).append("\n");
		    }
		    reader.close();
		    return sb.toString();
		} catch (IOException e) {
			e.printStackTrace();
			return "";
		}
	}
	
	// Return list of lines
	public List<String> listOfLines() {
		List<String> lines = new ArrayList<>();
		try {
			// Create reader
			BufferedReader replayReader = new BufferedReader(new FileReader(gameRecord));
			
			// Create list of lines
		    String line;
		    while ((line = replayReader.readLine()) != null) {
		        lines.add(line);
		    }
		    
		    // Close the reader and return lines
		    replayReader.close();
		    return lines;
	    // Exception block
		} catch (IOException e) {
			e.printStackTrace();
			return lines;
		}
	}
	
	// Return wether or not file begins with a randomized board state
	public boolean isRandomOnFile() {
		try {
			// Create reader
			BufferedReader fileReader = new BufferedReader(new FileReader(gameRecord));
			
			// Get list of lines
			String line;
			List<String> lines = new ArrayList<>();
			while ((line = fileReader.readLine()) != null) {
				lines.add(line);
			}
			
			// If first line is a randomized board code, return true.
			if (lines.get(0).startsWith("I")) {
				return true;
			}
			// Otherwise, return false
			else {
				return false;
			}
		// Handle exception
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		} catch (IndexOutOfBoundsException e) {
			return false;
		}
	}
	
	// Return whether or not any moves are recorded on the file
	public boolean haveMovesBeenMade() {
		try {
			// Create reader
			BufferedReader fileReader = new BufferedReader(new FileReader(gameRecord));
			
			// Get list of lines
			String line;
			List<String> lines = new ArrayList<>();
			while ((line = fileReader.readLine()) != null) {
				lines.add(line);
			}
			
			// If random is on file, check if there are at least two lines
			if (isRandomOnFile()) {
				return lines.size() > 1;
			}
			// If random is not on file, check if there is at least onne line
			else {
				return lines.size() > 0;
			}
		} catch (IOException e) {
			return false;
		}
	}
	
	// Get file
	public File getFile() {
		return gameRecord;
	}
}
