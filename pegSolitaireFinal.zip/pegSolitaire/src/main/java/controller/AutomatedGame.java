package controller;

import java.util.List;
import java.util.Random;

import model.Board;
import model.GameMode;
import model.GameScribe;
import model.Move;

public class AutomatedGame {
    private final Random randomGenerator = new Random();
    private Board board;
    private GameScribe scribe;
    private GameMode mode;

    public AutomatedGame(Board board, GameScribe scribe, GameMode mode) {
        this.board = board;
        this.scribe = scribe;
        this.mode = mode;
    }

    // Returns true if the move ended the game, false otherwise
    public boolean makeRandomMove() {
    	// Only do any of this if replay mode is not on
    	if (!mode.isReplay()) {
	        List<Move> moveList = board.getValidMoves();
	        try {
	        	// Get move
	            int index = randomGenerator.nextInt(moveList.size());
	            Move randomMove = moveList.get(index);
	            
	            // Make move
	            board.makeMove(randomMove.getStartR(), randomMove.getStartC(),
	                           randomMove.getEndR(), randomMove.getEndC());
	            
	            // Transcribe move
	            scribe.writeMove(randomMove.getStartR(), randomMove.getStartC(), randomMove.getEndR(), randomMove.getEndC());
	            
	            return !board.validMovesExist();
	        // Error handling for out-of-bounds move attempt
	        } catch (IllegalArgumentException e) {
	            return true;
	        }
    	}
    	return false;
    }
}