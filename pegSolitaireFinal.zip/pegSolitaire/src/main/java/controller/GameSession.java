package controller;

import model.Board;
import model.EnglishBoard;
import model.GameMode;
import model.GameScribe;

public class GameSession {
    private Board board;
    private boolean gameOver;
    private boolean messagePinged;
    private ManualGame manualController;
    private AutomatedGame automatedController;
    private GameScribe scribe;
    private GameMode mode;

    // Constructor
    public GameSession(Board board) {
        this.board = board;
        this.gameOver = false;
        this.messagePinged = false;
        this.mode = new GameMode();
        this.scribe = new GameScribe(mode);
        
        this.manualController = new ManualGame(board, scribe, mode);
        this.automatedController = new AutomatedGame(board, scribe, mode);
    }

    // Handle a manual click — delegates to ManualGame, then checks game state
    public void handleClick(int row, int col) {
        if (gameOver) return;
        boolean ended = manualController.handleClick(row, col);
        if (ended) {
            gameOver = true;
        }
    }

    // Handle an auto-play step — delegates to AutomatedGame, then checks game state
    public void handleAutoPlay() {
        if (gameOver) return;
        boolean ended = automatedController.makeRandomMove();
        if (ended) {
            gameOver = true;
        }
    }

    // Reset the board and all session state
    public void handleResetButton() {
        board.resetBoard();
        gameOver = false;
        messagePinged = false;
        scribe.wipeFile();
        manualController = new ManualGame(board, scribe, mode);
        automatedController = new AutomatedGame(board, scribe, mode);
    }

    // Randomize the board and reset session state
    public void handleRandomize() {
        board.randomize();
        scribe.wipeFile();
        mode.setReplay(false);
        while (!board.validMovesExist()) {
            board.randomize();
        }
        scribe.writeStringToFile(board.stateToString());
        gameOver = false;
        messagePinged = false;
        manualController = new ManualGame(board, scribe, mode);
        automatedController = new AutomatedGame(board, scribe, mode);
    }

    // Getters and setters

    public Board getBoard() {
        return board;
    }

    public boolean isGameOver() {
        return gameOver;
    }

    public boolean isMessagePinged() {
        return messagePinged;
    }

    public void setMessagePinged(boolean messagePinged) {
        this.messagePinged = messagePinged;
    }

    public ManualGame getMC() {
        return manualController;
    }

    public AutomatedGame getAC() {
        return automatedController;
    }
    
    public GameScribe getScribe() {
    	return scribe;
    }
    
    public GameMode getMode() {
    	return mode;
    }
}