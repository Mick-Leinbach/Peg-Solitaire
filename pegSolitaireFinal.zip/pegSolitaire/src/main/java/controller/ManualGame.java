package controller;
import model.Board;
import model.CellState;
import model.GameMode;
import model.GameScribe;

public class ManualGame {
    private int selectedRow;
    private int selectedCol;
    private Board board;
    private GameScribe scribe;
    private GameMode mode;

    public ManualGame(Board board, GameScribe scribe, GameMode mode) {
        this.board = board;
        this.scribe = scribe;
        this.mode = mode;
        selectedRow = -1;
        selectedCol = -1;
    }

    // Returns true if the move ended the game, false otherwise
    public boolean handleClick(int clickedRow, int clickedCol) {
    	// Make sure we're not in replay mode before checking any of this
    	if (!mode.isReplay()) {
	        if ((clickedRow < 0) || (clickedRow > board.GRID_SIZE - 1) ||
	            (clickedCol < 0) || (clickedCol > board.GRID_SIZE - 1)) {
	            return false;
	        }
	
	        if ((clickedRow == selectedRow) && (clickedCol == selectedCol)) {
	            selectedRow = -1;
	            selectedCol = -1;
	        }
	        else if (board.getGrid()[clickedRow][clickedCol].getState() == CellState.INVALID) {
	            selectedRow = -1;
	            selectedCol = -1;
	        }
	        else if (board.getGrid()[clickedRow][clickedCol].getState() == CellState.EMPTY) {
	            if (selectedRow == -1 || !board.isValid(selectedRow, selectedCol, clickedRow, clickedCol)) {
	                selectedRow = -1;
	                selectedCol = -1;
	            } else {
	            	// Make the move
	                board.makeMove(selectedRow, selectedCol, clickedRow, clickedCol);
	                
	                // Transcribe move
	                scribe.writeMove(selectedRow, selectedCol, clickedRow, clickedCol);
	                
	                // Delected and return whether game contineus
	                selectedRow = -1;
	                selectedCol = -1;
	                return !board.validMovesExist();
	            }
	        }
	        else if (board.getGrid()[clickedRow][clickedCol].getState() == CellState.PEG) {
	            selectedRow = clickedRow;
	            selectedCol = clickedCol;
	        }
    	}
        return false;
    }

    public int getSelectedRow() {
        return selectedRow;
    }
    
    public void setSelectedRow(int row) {
    	this.selectedRow = row;
    }

    public int getSelectedCol() {
        return selectedCol;
    }
    
    public void setSelectedCol(int col) {
    	this.selectedCol = col;
    }
}