package model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class DiamondBoardTest {
	@Test
	public void testDiBoardSize() {
		DiamondBoard diamondBoard = new DiamondBoard(7);
		assertEquals(7, diamondBoard.getBoardSize());
	}
	
	@Test
	public void testSizeSevenDiBoard() {
		DiamondBoard diamondBoard = new DiamondBoard(7);
		assertEquals(CellState.INVALID, diamondBoard.getGrid()[5][5].getState());
		assertEquals(CellState.INVALID, diamondBoard.getGrid()[9][5].getState());
		assertEquals(CellState.PEG, diamondBoard.getGrid()[5][6].getState());
		assertEquals(CellState.PEG, diamondBoard.getGrid()[9][6].getState());
		assertEquals(CellState.EMPTY, diamondBoard.getGrid()[7][7].getState());
		assertEquals(CellState.INVALID, diamondBoard.getGrid()[4][6].getState());
		assertEquals(CellState.INVALID, diamondBoard.getGrid()[11][7].getState());
	}
	
	@Test
	public void testSizeFifteenDiBoard() {
		DiamondBoard diamondBoard = new DiamondBoard(15);
		assertEquals(CellState.PEG, diamondBoard.getGrid()[0][7].getState());
		assertEquals(CellState.PEG, diamondBoard.getGrid()[7][0].getState());
		assertEquals(CellState.PEG, diamondBoard.getGrid()[14][7].getState());
		assertEquals(CellState.PEG, diamondBoard.getGrid()[7][14].getState());
		assertEquals(CellState.EMPTY, diamondBoard.getGrid()[7][7].getState());
		assertEquals(CellState.INVALID, diamondBoard.getGrid()[0][6].getState());
		assertEquals(CellState.INVALID, diamondBoard.getGrid()[0][8].getState());
		assertEquals(CellState.INVALID, diamondBoard.getGrid()[6][14].getState());
		assertEquals(CellState.INVALID, diamondBoard.getGrid()[8][14].getState());
	}
}