package model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class HexagonBoardTest {
	@Test
	public void testHexBoardSize() {
		HexagonBoard hexagonBoard = new HexagonBoard(7);
		assertEquals(7, hexagonBoard.getBoardSize());
	}
	
    @Test
    void testSizeSevenHexBoard() {
        HexagonBoard hexagonBoard = new HexagonBoard(7);
        Square[][] grid = hexagonBoard.getGrid();

        // --- Top margin should be invalid
        assertEquals(CellState.INVALID, grid[0][0].getState());
        assertEquals(CellState.INVALID, grid[0][7].getState());
        assertEquals(CellState.INVALID, grid[0][6].getState());

        // --- First playable row
        assertEquals(CellState.PEG, grid[4][7].getState());
        assertEquals(CellState.INVALID, grid[4][0].getState());
        assertEquals(CellState.PEG, grid[4][6].getState());

        // --- Center row
        assertEquals(CellState.PEG, grid[7][6].getState());
        assertEquals(CellState.EMPTY, grid[7][7].getState());
        assertEquals(CellState.PEG, grid[7][8].getState());

        // --- Bottom playable region
        assertEquals(CellState.PEG, grid[5][7].getState());

        // --- Bottom margin
        assertEquals(CellState.INVALID, grid[6][0].getState());
        assertEquals(CellState.INVALID, grid[7][11].getState());
        assertEquals(CellState.INVALID, grid[9][10].getState());
    }
    
    @Test
    void testSizeFifteenHexBoard() {
        HexagonBoard board = new HexagonBoard(15);
        Square[][] grid = board.getGrid();

        // --- Top margin invalid
        assertEquals(CellState.INVALID, grid[0][0].getState());
        assertEquals(CellState.PEG, grid[0][7].getState());
        assertEquals(CellState.INVALID, grid[0][14].getState());

        // --- Early playable row
        assertEquals(CellState.PEG, grid[3][7].getState());
        assertEquals(CellState.INVALID, grid[3][0].getState());

        // --- Center row checks
        assertEquals(CellState.PEG, grid[7][5].getState());
        assertEquals(CellState.PEG, grid[7][6].getState());
        assertEquals(CellState.EMPTY, grid[7][7].getState());
        assertEquals(CellState.PEG, grid[7][8].getState());
        assertEquals(CellState.PEG, grid[7][9].getState());

        // --- Lower playable region
        assertEquals(CellState.PEG, grid[11][7].getState());

        // --- Bottom margin
        assertEquals(CellState.INVALID, grid[14][0].getState());
        assertEquals(CellState.PEG, grid[14][7].getState());
        assertEquals(CellState.INVALID, grid[14][14].getState());
    }
	
}