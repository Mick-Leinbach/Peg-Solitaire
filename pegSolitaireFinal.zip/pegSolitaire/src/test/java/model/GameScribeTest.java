package model;
import org.junit.jupiter.api.Test;
import org.junit.platform.commons.util.StringUtils;

import static org.junit.jupiter.api.Assertions.*;

import controller.GameSession;
import model.Board;
import model.EnglishBoard;

public class GameScribeTest {
	
	@Test
	public void testTranscribeManual() {
		// Game session NOT in replay mode, blank slate record
		GameSession session = new GameSession(new EnglishBoard(7));
		GameScribe scribe = session.getScribe();
		session.getMode().setReplay(false);
		session.getScribe().wipeFile();

		// Valid manual moves
		session.getMC().setSelectedRow(7);
		session.getMC().setSelectedCol(5);
		session.handleClick(7, 7);
		
		session.getMC().setSelectedRow(7);
		session.getMC().setSelectedCol(8);
		session.handleClick(7, 6);
		
		session.getMC().setSelectedRow(7);
		session.getMC().setSelectedCol(8);
		session.handleClick(7, 6);
		
		session.getMC().setSelectedRow(7);
		session.getMC().setSelectedCol(10);
		session.handleClick(7, 8);
		
		// Oracle: Are the moves saved?
		assertEquals(scribe.readFile(),"7 5 7 7\n7 8 7 6\n7 10 7 8\n");
	}
	
	@Test 
	public void testTranscribeAutomated() {
		// Game session NOT in replay mode, blank slate record
		GameSession session = new GameSession(new EnglishBoard(7));
		GameScribe scribe = session.getScribe();
		session.getMode().setReplay(false);
		session.getScribe().wipeFile();
		
		// Make some automated moves
		session.getAC().makeRandomMove();
		session.getAC().makeRandomMove();
		session.getAC().makeRandomMove();
		
		// Oracle: Have three moves been recorded?
		long count = scribe.readFile().chars().filter(c -> c == '\n').count();
		assertEquals(3, count);
	}
	
	@Test
	public void testDontWriteDuringReplay() {
		// Game session IS in replay mode, blank slate record
		GameSession session = new GameSession(new EnglishBoard(7));
		GameScribe scribe = session.getScribe();
		session.getMode().setReplay(true);
		session.getScribe().wipeFile();
		String startFile = scribe.readFile();
		
		// Make some manual moves
		session.getMC().setSelectedRow(7);
		session.getMC().setSelectedCol(5);
		session.handleClick(7, 7);
		
		session.getMC().setSelectedRow(7);
		session.getMC().setSelectedCol(8);
		session.handleClick(7, 6);
		
		// Make some automated moves
		session.getAC().makeRandomMove();
		session.getAC().makeRandomMove();
		
		// Oracle 1: The text file should be exactly the same
		assertEquals(startFile, scribe.readFile());
		
		// Make some automated moves with replay off
		session.getMode().setReplay(false);
		session.getAC().makeRandomMove();
		session.getAC().makeRandomMove();
		
		// Oracle 2: The text file should be updated
		long count = scribe.readFile().chars().filter(c -> c == '\n').count();
		assertEquals(2, count);
		String secondFile = scribe.readFile();
		
		// Turn on replay and make some moves
		session.getMode().setReplay(true);
		session.getAC().makeRandomMove();
		session.getAC().makeRandomMove();
		
		// Oracle 3: Text file should remain the same
		assertEquals(secondFile, scribe.readFile());
	}
	
	@Test 
	public void dontTranscribeInvalidMoves() {
		// Game session NOT in replay mode, blank slate record
		GameSession session = new GameSession(new EnglishBoard(7));
		GameScribe scribe = session.getScribe();
		session.getMode().setReplay(false);
		session.getScribe().wipeFile();
		String startFile = scribe.readFile();
		
		// Make some invalid manual moves
		session.getMC().setSelectedRow(6);
		session.getMC().setSelectedRow(4);
		session.handleClick(8, 4);
		
		session.getMC().setSelectedRow(6);
		session.getMC().setSelectedRow(4);
		session.handleClick(6, 3);
		
		session.getMC().setSelectedRow(6);
		session.getMC().setSelectedRow(4);
		session.handleClick(6, 5);
		
		session.getMC().setSelectedRow(6);
		session.getMC().setSelectedRow(4);
		session.handleClick(6, 4);
		
		// Oracle: Text file should be the same
		assertEquals(startFile, scribe.readFile());
	}
	
	@ Test
	public void dontRecordAutomatedIfGameOver() {
		// Game session NOT in replay mode, blank slate record
		GameSession session = new GameSession(new EnglishBoard(7));
		GameScribe scribe = session.getScribe();
		session.getMode().setReplay(false);
		session.getScribe().wipeFile();
		
		// End the game
		while (session.getBoard().validMovesExist()) {
			session.getAC().makeRandomMove();
		}
		
		// Record state of record
		String originalFile = scribe.readFile();
		
		// Attempt to make more automated moves
		session.getAC().makeRandomMove();
		session.getAC().makeRandomMove();
		session.getAC().makeRandomMove();
		
		// Oracle: File should be unchanged
		assertEquals(originalFile, scribe.readFile());
	}
	
	@ Test
	public void testRecordWipe() {
		// New game session
		GameSession session = new GameSession(new EnglishBoard(7));
		GameScribe scribe = session.getScribe();
		session.getMode().setReplay(false);
		session.getScribe().wipeFile();
		
		// Make some moves
		session.getAC().makeRandomMove();
		session.getAC().makeRandomMove();
		
		// Reset button pressed
		session.handleResetButton();
		
		// Oracle 1: Reset button wipes file
		assertEquals("", scribe.readFile());
		
		// Make some moves
		session.getAC().makeRandomMove();
		session.getAC().makeRandomMove();
	
		// Save record state
		String orgFile = scribe.readFile();
		
		// Randomize
		session.handleRandomize();
		
		// Oracle 2: Record should not be the same
		assertTrue(!orgFile.equals(scribe.readFile()));
	}
	
	@ Test
	public void testRecordRandomizedState() {
		// Game session
		GameSession session = new GameSession(new EnglishBoard(7));
		GameScribe scribe = session.getScribe();
		session.getMode().setReplay(false);
		session.getScribe().wipeFile();
		
		// Board is randomized (this should record the board state to the record)
		session.handleRandomize();
		
		// Get state of board
		String boardState = session.getBoard().stateToString();
		
		// Oracle: Board state matches what is on file
		assertEquals(boardState.concat("\n"), scribe.readFile());
		
		// Make some moves
		session.getAC().makeRandomMove();
		session.getAC().makeRandomMove();
		
		// Oracle 2: There should now be three lines in the file
		long count = scribe.readFile().chars().filter(c -> c == '\n').count();
		assertEquals(3, count);
	}
	
	@ Test
	public void testIsRandomBoardOnFile() {
		// Game session
		GameSession session = new GameSession(new EnglishBoard(7));
		GameScribe scribe = session.getScribe();
		Board board = session.getBoard();
		session.getScribe().wipeFile();
		
		// Oracle 1: There should NOT be a random board on flie
		assertFalse(scribe.isRandomOnFile());
		
		// Randomize
		session.handleRandomize();
		
		// Oracle 2: There SHOULD be a random board on file
		assertTrue(scribe.isRandomOnFile());
		
		// Make some moves
		session.getAC().makeRandomMove();
		session.getAC().makeRandomMove();
		
		// Oracle 3: There should still be a random board on file
		assertTrue(scribe.isRandomOnFile());
		
		// Reset file
		scribe.wipeFile();
		
		// Oracle 4: There should NOT be a random board on flie
		assertFalse(scribe.isRandomOnFile());
	}
	
	@ Test
	public void testHaveMovesBeenMade() {
		// Game session
		GameSession session = new GameSession(new EnglishBoard(7));
		GameScribe scribe = session.getScribe();
		Board board = session.getBoard();
		session.getScribe().wipeFile();
		
		// Oracle 1: should return false on new game
		assertFalse(scribe.haveMovesBeenMade());
		
		// Make some moves
		session.getAC().makeRandomMove();
		session.getAC().makeRandomMove();
		
		// Oracle 2: Should return true
		assertTrue(scribe.haveMovesBeenMade());
		
		// Randomize board
		session.handleRandomize();
		
		// Oracle 3: Should return false
		assertFalse(scribe.haveMovesBeenMade());
		
		// Make some moves
		session.getAC().makeRandomMove();
		session.getAC().makeRandomMove();
		
		// Oracle 4: Should return true
		assertTrue(scribe.haveMovesBeenMade());
		
		// Reset
		session.handleResetButton();
		
		// Oracle 5: Should return false
		assertFalse(scribe.haveMovesBeenMade());
	}
}
