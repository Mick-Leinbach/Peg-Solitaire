import java.util.Scanner;

public class AreaRectangle
{
   public static void main(String[] args)
   {
      double length,    // The rectangle's length
             width,     // The rectangle's width
             area;      // The rectangle's area

      // Get the rectangle's length from the user.
      length = getLength();

      // Get the rectangle's width from the user.
      width = getWidth();

      // Get the rectangle's area.
      area = getArea(length, width);

      // Display the rectangle data.
      displayData(length, width, area);
   }

   public static double getLength()
   {
      Scanner scanner = new Scanner(System.in);
      System.out.print("Enter the rectangle's length: ");
      return scanner.nextDouble();
   }

   public static double getWidth()
   {
      Scanner scanner = new Scanner(System.in);
      System.out.print("Enter the rectangle's width: ");
      return scanner.nextDouble();
   }

   public static double getArea(double length, double width)
   {
      return length * width;
   }

   public static void displayData(double length, double width, double area)
   {
      System.out.println("The rectangle's length is " + length);
      System.out.println("The rectangle's width is " + width);
      System.out.println("The rectangle's area is " + area);
   }
}

