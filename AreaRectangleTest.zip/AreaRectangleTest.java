
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AreaRectangleTest {
	@Test
	void getAreaShouldCalculateCorrectly() {
		double result = AreaRectangle.getArea(5.0, 3.0);
		assertEquals(15.0, result);
	}
	
	@Test
	void getAreaShouldHandleDecimals() {
		double result = AreaRectangle.getArea(2.5, 4.2);
		assertEquals(10.5, result, 0.0001);
	}
}
